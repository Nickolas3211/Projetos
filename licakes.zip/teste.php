<div id="myModal" class="modal">

    <!-- Modal content -->
    <div class="modal-content">
      <div class="modal-header">
        <span class="close">&times;</span>
        <h2>Mousse de Chocolate</h2>
      </div>
      <div class="modal-body">
        <p>Esse é um delicioso bolo de mousse de chocolate, feito com muito carinho e combino muito bem com coquinha gelada.</p>
        <p>Ingredientes:</p>
        <p>Chocolate nobre</p>
        <p>Leite Condesado</p>
        <p>Farinha</p>
      </div>
      <div class="modal-footer">
        <h3>Gostou do bolo? Baixe nosso app <a href="#">clicando aqui.<a/></h3>
      </div>
    </div>
  
</div>

<button id="myBtn"><img src="img/bolo_mousse1.png" alt="img galeria"></button>