<!--PROMOCAO-->
<section class="promocao">
    <img src="img/bannerPromocao1.png" alt="">
    <img src="img/bannerPromocao2.png" alt="">
    <img src="img/bannerPromocao3.png" alt="">
</section>
<!--FIM PROMOCAO-->