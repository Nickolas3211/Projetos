<!--CABEÇALHO-->
<header>
    <div class="topoBotoes">
        <div class="site">
            <button class="abrir-menu"></button>  
            <nav class="Menu">
                <button class="fechar-menu"></button>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="sobre.php">Sobre</a></li>
                    <li><a href="app.php">app</a></li>
                    <a href="index.php">
                    <img src="img/logos/novaLogov3.png" alt="logo da LiCakes">
                    </a>
                    <li><a href="produtos.php">produtos</a></li>
                    <li><a href="equipe.php">equipe</a></li>
                    <li><a href="contato.php">contato</a></li>
                </ul>
            </nav>
        </div>
    </div>
</header>
<!--FIM CABEÇALHO-->