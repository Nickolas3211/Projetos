<!--BANNER-->
<section class="banner">
    <img src="img/banner1.png" alt="Um banner de bolo">
    <img src="img/banner2.png" alt="Um banner de bolo">
    <img src="img/banner3.png" alt="Um banner de bolo">
    <img src="img/banner4.png" alt="Um banner de bolo">
    <img src="img/banner5.png" alt="Um banner de bolo">
</section>
<!--FIM BANNER-->